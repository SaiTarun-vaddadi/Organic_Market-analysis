SHOW DATABASES;
USE organic_market;

SELECT * FROM organic_products_survey;

SELECT ORGANIC_CATEGORY,
COUNT(*) AS product_count
FROM organic_products_survey
GROUP BY ORGANIC_CATEGORY
ORDER BY product_count DESC;

SELECT ORGANIC_CATEGORY,AVG(PRICE) AS avg_price
FROM organic_products_survey
GROUP BY ORGANIC_CATEGORY
ORDER BY avg_price DESC;

SELECT SALES_INDICATOR,
       COUNT(*) AS indicator_count
FROM organic_products_survey
GROUP BY SALES_INDICATOR;
